<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::group(['prefix' => 'auth'], function () {
    Route::post('register_armada', 'AuthController@storeArmada');
    Route::post('register_loket', 'AuthController@storeLoket');
    Route::post('register_nahkoda', 'AuthController@storeNahkoda');
    Route::post('login', 'AuthController@login');
//    Route::group(['middleware' => 'jwt.verify'], function () {
//        Route::post('login', 'AuthController@login');
//    });
});

Route::group(['middleware' => 'jwt.verify'], function () {
    Route::group(['prefix' => 'nahkoda'], function () {
        Route::get('profile/{id_user}', 'NahkodaController@view');
        Route::get('{id_armada}', 'NahkodaController@index');
        Route::post('profile/{id_user}', 'NahkodaController@edit');
    });
});

    Route::group(['prefix' => 'armada'], function () {
        Route::get('{id_armada}', 'ArmadaController@view');
        Route::get('', 'ArmadaController@index');
        Route::post('{id_armada}', 'ArmadaController@edit')->middleware('jwt.verify');
        Route::post('', 'ArmadaController@store')->middleware('jwt.verify');
    });

    Route::group(['prefix' => 'kapal'], function () {
        Route::get('profile/{id_kapal}', 'KapalController@view');
        Route::get('{id_armada}', 'KapalController@index');
        Route::post('{id_kapal}', 'KapalController@edit')->middleware('jwt.verify');
        Route::post('', 'KapalController@store')->middleware('jwt.verify');
    });

Route::group(['middleware' => 'jwt.verify'], function () {
    Route::group(['prefix' => 'jenis_kapal'], function () {
        Route::get('{id_jenis}', 'JenisKapalController@view');
        Route::get('', 'JenisKapalController@index');
        Route::post('{id_jenis}', 'JenisKapalController@edit');
        Route::post('', 'JenisKapalController@store');
    });

    Route::group(['prefix' => 'status_kapal'], function () {
        Route::get('{id_status}', 'StatusKapalController@view');
        Route::get('', 'StatusKapalController@index');
        Route::post('{id_status}', 'StatusKapalController@edit');
        Route::post('', 'StatusKapalController@store');
    });

    Route::group(['prefix' => 'dermaga'], function () {
        Route::post('', 'DermagaController@store');
    });
});

Route::group(['prefix' => 'rute'], function () {
    Route::get('{id_rute}', 'RuteController@view');
    Route::get('list/now', 'RuteController@list_now');
    Route::get('', 'RuteController@index');
    Route::post('{id_rute}', 'RuteController@edit')->middleware('jwt.verify');
    Route::post('', 'RuteController@store')->middleware('jwt.verify');
});

    Route::group(['prefix' => 'jadwal_keberangkatan'], function () {
        Route::get('view/{id_jadwal}', 'JadwalKeberangkatanController@view');
        Route::get('{id_armada}', 'JadwalKeberangkatanController@index');
        Route::post('edit/{id_jadwal}', 'JadwalKeberangkatanController@edit')->middleware('jwt.verify');
        Route::post('{id_armada}', 'JadwalKeberangkatanController@store')->middleware('jwt.verify');
        Route::post('start/{id_jadwal}', 'JadwalKeberangkatanController@start')->middleware('jwt.verify');
        Route::post('stop/{id_jadwal}', 'JadwalKeberangkatanController@stop')->middleware('jwt.verify');
        Route::post('reset/now', 'JadwalKeberangkatanController@reset')->middleware('jwt.verify');
        Route::get('view/now/{id_armada}', 'JadwalKeberangkatanController@view_now');
        Route::get('view/penumpang/{id_jadwal}', 'JadwalKeberangkatanController@view_penumpang')->middleware('jwt.verify');
        Route::get('view/rute/{id_rute}', 'JadwalKeberangkatanController@view_rute')->middleware('jwt.verify');
        Route::get('list/{id_nahkoda}', 'JadwalKeberangkatanController@list_nahkoda')->middleware('jwt.verify');
        Route::get('keberangkatan/{id_armada}', 'JadwalKeberangkatanController@keberangkatan')->middleware('jwt.verify');
        Route::get('view_keberangkatan/{id_jadwal}', 'JadwalKeberangkatanController@view_keberangkatan')->middleware('jwt.verify');
        Route::get('rute/{id_rute}', 'JadwalKeberangkatanController@view_rute');
        Route::get('kapal/{id_kapal}', 'JadwalKeberangkatanController@view_kapal');
    });

Route::group(['middleware' => 'jwt.verify'], function () {
    Route::group(['prefix' => 'jenis_tujuan'], function () {
        Route::get('{id_tujuan}', 'JenisTujuanController@view');
        Route::get('', 'JenisTujuanController@index');
        Route::post('{id_tujuan}', 'JenisTujuanController@edit');
        Route::post('', 'JenisTujuanController@store');
    });

    Route::group(['prefix' => 'jenis_penumpang'], function () {
        Route::get('{id_jns_penumpang}', 'JenisPenumpangController@view');
        Route::get('', 'JenisPenumpangController@index');
        Route::post('{id_jns_penumpang}', 'JenisPenumpangController@edit');
        Route::post('', 'JenisPenumpangController@store');
    });

    Route::group(['prefix' => 'penumpang'], function () {
        Route::get('{penumpang}', 'PenumpangController@view');
        Route::get('', 'PenumpangController@index');
        Route::post('{penumpang}', 'PenumpangController@edit');
        Route::post('', 'PenumpangController@store');
    });

    Route::group(['prefix' => 'sop'], function () {
        Route::get('', 'SopController@view');
        Route::post('{penumpang}', 'SopController@edit');
        Route::post('', 'SopController@store');
    });

    Route::group(['prefix' => 'dashboard'], function () {
        Route::get('/penumpang/{query}', 'DashboardController@grafikPenumpang');
        Route::get('/keberangkatan/{query}', 'DashboardController@grafikKeberangkatan');
        Route::get('/kapal', 'DashboardController@grafikKapal');
        Route::get('/jenis_penumpang/{query}', 'DashboardController@grafikJenis');
    });
});

Route::post('test', 'KapalController@test');


