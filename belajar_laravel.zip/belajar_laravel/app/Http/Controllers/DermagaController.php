<?php

namespace App\Http\Controllers;

use App\Dermaga;
use Illuminate\Http\Request;

class DermagaController extends Controller
{
    //
    public function store(Request $request) {
        $this->validate($request,[
            'nama_dermaga' => 'required|string',
            'lokasi' => 'required|string'
        ]);

        $dermaga = new Dermaga([
            'nama_dermaga' => $request->input('nama_dermaga'),
            'lokasi' => $request->input('lokasi')
        ]);

        if($dermaga->save()) {
            $response = [
                'message' => 'Dermaga created',
                'dermaga' => $dermaga
            ];

            return response()->json($response, 201);
        }

        return response()->json(['message' => 'Dermaga not created'], 404);
    }
}
