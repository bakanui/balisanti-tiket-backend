<?php

namespace App\Http\Controllers;

use App\Nahkoda;
use App\User;
use Illuminate\Http\Request;

class NahkodaController extends Controller
{
    //
    public function view($id_user) {
        $user = User::query()->where('id', $id_user)->get();
        $nahkoda = Nahkoda::query()->where('id_nahkoda', $id_user)->get();

        $response = [
            'user' => $user,
            'nahkoda' => $nahkoda
        ];

        return response()->json($response, 200);
    }

    public function index($id_armada) {
        $nahkoda = Nahkoda::query()->with('nahkodaToArmada')->where('id_armada', $id_armada)->get();

        return response()->json($nahkoda, 200);
    }

    public function edit(Request $request, $id_user) {
        $this->validate($request, [
            'nama_nahkoda' => 'required|string',
            'no_hp' => 'required|string'
        ]);

        $nahkoda = [
            'nama_nahkoda' => $request->input('nama_nahkoda'),
            'no_hp' => $request->input('no_hp'),
        ];

        $data = Nahkoda::query()->where('id_nahkoda', $id_user);

        if ($data->update($nahkoda)) {
            $response = [
                'message' => 'User Edited',
                'user' => User::query()->where('id', $id_user)->get(),
                'nahkoda' => $data->get()
            ];

            return response()->json($response, 201);
        }

        return response()->json(['User not Edited'], 404);
    }
}
