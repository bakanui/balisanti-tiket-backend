<?php

namespace App\Http\Controllers;

use App\SOP;
use Illuminate\Http\Request;

class SopController extends Controller
{
    //
    public function view() {
        $sop = SOP::query()->get();

        return response()->json($sop, 200);
    }

    public function store(Request $request) {
        $this->validate($request, [
            'description' => 'required'
        ]);

        $sop = new SOP([
            'description' => $request->input('description')
        ]);

        if($sop->save()) {
            return response()->json(['msg' => 'SOP created'], 200);
        }

        return response()->json(['msg' => 'SOP not created'], 404);
    }
}
