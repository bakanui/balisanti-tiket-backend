<?php

namespace App\Http\Controllers;

use App\JadwalKeberangkatan;
use App\Kapal;
use App\Rute;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class JadwalKeberangkatanController extends Controller
{
    //
    public function store(Request $request, $id_armada) {
        $this->validate($request,[
            'jadwal' => 'required',
            'status' => 'required|string',
            'harga' => 'required|integer',
            'id_nahkoda' => 'required',
            'id_kapal' => 'required',
            'id_rute' => 'required',
        ]);

        $jadwal = new JadwalKeberangkatan([
            'id_jadwal' => uniqid(),
            'jadwal' => $request->input('jadwal'),
            'status' => $request->input('status'),
            'harga' => $request->input('harga'),
            'id_armada' => $id_armada,
            'id_nahkoda' => $request->input('id_nahkoda'),
            'id_kapal' => $request->input('id_kapal'),
            'id_rute' => $request->input('id_rute')
        ]);

        if ($jadwal->save()) {
            $response = [
                'message' => 'Jadwal created',
                'jadwal' => $jadwal
            ];

            return response()->json($response, 201);
        }

        return response()->json(['message' => 'Jadwal not created'], 404);
    }

    public function view($id_jadwal) {
        $jadwal = JadwalKeberangkatan::query()
            ->with('jadwalToArmada')
            ->with('jadwalToNahkoda')
            ->with('jadwalToKapal')
            ->with('jadwalToRute')
            ->with('jadwalToPenumpang')
            ->where('id_jadwal', $id_jadwal)->first();

        return response()->json($jadwal, 200);
    }

    public function list_nahkoda($id_nahkoda) {
        $jadwal = JadwalKeberangkatan::query()
            ->select('jadwal_keberangkatans.*')
            ->with('jadwalToNahkoda')
            ->with('jadwalToKapal')
            ->with('jadwalToRute')
            ->with('jadwalToPenumpang')
            ->leftJoin('history_keberangkatan', 'jadwal_keberangkatans.id_jadwal', '=', 'history_keberangkatan.id_jadwal')
            ->where(function($query) use ($id_nahkoda){
                $query->where('history_keberangkatan.type', '=', null);
                $query->where('id_nahkoda', $id_nahkoda);
            })
            ->orWhere(function($query) use ($id_nahkoda){
                $query->where('history_keberangkatan.type', '=', 'stop');
                $query->whereDate('history_keberangkatan.tanggal', '!=',Carbon::now('+08:00'));
                $query->where('id_nahkoda', $id_nahkoda);
            })
            ->groupBy('jadwal_keberangkatans.id_jadwal')
            ->paginate(10);

        $return = array();
        $return['data'] = $jadwal->items();
        $return['link'] = (object) array(
            'first_page_url' => $jadwal->url($jadwal->firstItem()),
            'last_page_url' => $jadwal->url($jadwal->lastPage()),
            'next_page_url' => $jadwal->nextPageUrl(),
            'prev_page_url' => $jadwal->previousPageUrl()
        );
        $return['meta'] = (object) array(
            'current_page' => $jadwal->currentPage(),
            'per_page' => $jadwal->perPage(),
            'total' => $jadwal->total(),
            'last_page' => $jadwal->lastPage(),
            'from' => $jadwal->firstItem()
        );

        return response()->json($return, 200);
    }

    public function index($id_armada) {
        $jadwal = JadwalKeberangkatan::query()
            ->with('jadwalToArmada')
            ->with('jadwalToNahkoda')
            ->with('jadwalToKapal')
            ->with('jadwalToRute')
            ->with('jadwalToPenumpang')
            ->where('id_armada', $id_armada)->get();

        return response()->json($jadwal, 200);
    }

    public function keberangkatan(Request $request, $id_armada) {
        $tanggal = $request->query('tanggal');
        $jadwal = DB::table('keberangkatans as k')
            ->select('k.id_jadwal','jk.*', 'kp.nama_kapal', 'd.nama_dermaga as tujuan_awal', 'dt.nama_dermaga as tujuan_akhir', DB::raw('COUNT(k.id_penumpang) as total'))
            ->join('jadwal_keberangkatans as jk', 'jk.id_jadwal', '=', 'k.id_jadwal')
            ->join('penumpangs as p', 'k.id_penumpang', '=', 'p.id')
            ->join('rutes as r', 'jk.id_rute', '=', 'r.id_rute')
            ->join('dermagas as d', 'r.tujuan_awal', '=', 'd.id_dermaga')
            ->join('dermagas as dt', 'r.tujuan_akhir', '=', 'dt.id_dermaga')
            ->join('kapals as kp', 'kp.id_kapal', '=', 'jk.id_kapal')
            ->where('jk.id_armada','=', $id_armada)
            ->whereDate('k.tanggal_keberangkatan', '=', $tanggal)
            ->groupBy('k.id_jadwal')
            ->get();

        return response()->json($jadwal, 200);
    }

    public function view_keberangkatan(Request $request, $id_jadwal) {
        $tanggal = $request->query('tanggal');
        $jadwal = DB::table('keberangkatans as k')
            ->select('*')
            ->join('jadwal_keberangkatans as jk', 'jk.id_jadwal', '=', 'k.id_jadwal')
            ->join('penumpangs as p', 'k.id_penumpang', '=', 'p.id')
            ->join('rutes as r', 'jk.id_rute', '=', 'r.id_rute')
            ->join('dermagas as d', 'r.tujuan_awal', '=', 'd.id_dermaga')
            ->join('dermagas as dt', 'r.tujuan_akhir', '=', 'dt.id_dermaga')
            ->join('kapals as kp', 'kp.id_kapal', '=', 'jk.id_kapal')
            ->join('jenis_penumpangs as jp', 'jp.id_jns_penum', '=', 'p.id_jns_penum')
            ->join('jenis_tujuans as jt', 'jt.id_tujuan', '=', 'p.id_tujuan')
            ->where('jk.id_jadwal','=', $id_jadwal)
            ->whereDate('k.tanggal_keberangkatan', '=', $tanggal)
            ->get();

        return response()->json($jadwal, 200);
    }

    public function edit(Request $request, $id_jadwal) {
        $this->validate($request,[
            'jadwal' => 'required',
            'status' => 'required|string',
            'harga' => 'required|integer',
            'id_nahkoda' => 'required',
            'id_kapal' => 'required',
            'id_rute' => 'required',
        ]);

        $jadwal = [
            'jadwal' => $request->input('jadwal'),
            'status' => $request->input('status'),
            'harga' => $request->input('harga'),
            'id_nahkoda' => $request->input('id_nahkoda'),
            'id_kapal' => $request->input('id_kapal'),
            'id_rute' => $request->input('id_rute')
        ];

        $data = JadwalKeberangkatan::query()
            ->with('jadwalToArmada')
            ->with('jadwalToNahkoda')
            ->with('jadwalToKapal')
            ->with('jadwalToRute')
            ->where('id_jadwal', $id_jadwal);

        if ($data) {
            if ($data->update($jadwal)) {
                $response = [
                    'message' => 'Jadwal edited',
                    'jadwal' => $data->get()
                ];

                return response()->json($response, 201);
            }

            return response()->json(['message' => 'Jadwal not edited'], 404);
        }

        return response()->json(['message' => 'Jadwal not found'], 404);
    }

    public function start($id_jadwal) {
        $data = array(
            'id_jadwal' => $id_jadwal,
            'type' => 'start',
            'tanggal' => Carbon::now('+08:00')
        );

        $tmp = array(
            'status' => 'start'
        );

        $sql = JadwalKeberangkatan::query()->where('id_jadwal', $id_jadwal);
        $id_kapal = JadwalKeberangkatan::query()->select('id_kapal')->where('id_jadwal', $id_jadwal)->first();
        $kilometer = Kapal::query()->select('kilometer')->where('id_kapal', $id_kapal['id_kapal'])->first();
        $query = DB::table('history_keberangkatan');

        $id = $query->insertGetId($data);
            if ($id && $sql->update($tmp)) {
                $response = [
                    'message' => 'Start now',
                    'jadwal' => $query->where('id', $id)->first(),
                    'kilometer' => $kilometer['kilometer']
                ];

                return response()->json($response, 201);
            }

            return response()->json(['message' => 'Start failed'], 404);
    }

    public function stop(Request $request, $id_jadwal) {
        $kilometer = $request->query('kilometer');

        $data = array(
            'id_jadwal' => $id_jadwal,
            'type' => 'stop',
            'tanggal' => Carbon::now('+08:00')
        );

        $tmp = array(
            'status' => 'nyandar'
        );

        $id_kapal = JadwalKeberangkatan::query()->select('id_kapal')->where('id_jadwal', $id_jadwal)->first();
        $kapal = Kapal::query()->where('id_kapal', $id_kapal['id_kapal']);
        $kapal->update([
            'kilometer' => $kilometer
        ]);

        $sql = JadwalKeberangkatan::query()->where('id_jadwal', $id_jadwal);
        $query = DB::table('history_keberangkatan');
        $id = $query->insertGetId($data);
        if ($id && $sql->update($tmp)) {
            $response = [
                'message' => 'Stop now',
                'jadwal' => $query->where('id', $id)->first()
            ];

            return response()->json($response, 201);
        }

        return response()->json(['message' => 'Stop  failed'], 404);
    }

    public function view_now($id_armada) {
        $jadwal = JadwalKeberangkatan::query()
            ->with('jadwalToArmada')
            ->with('jadwalToNahkoda')
            ->with('jadwalToKapal')
            ->with('jadwalToRute')
            ->where('id_armada', $id_armada)
            ->whereDate('jadwal', Carbon::now('+08:00'))->get();

        return response()->json($jadwal, 200);
    }

    public function view_rute($id_rute) {
        $jadwal = JadwalKeberangkatan::query()
            ->with('jadwalToArmada')
            ->with('jadwalToKapal')
            ->with('jadwalToRute')
            ->where('id_rute', $id_rute)
            ->whereDate('jadwal', Carbon::today())->get();

        return response()->json($jadwal, 200);
    }

    public function view_penumpang($id_jadwal) {
        $jadwal = JadwalKeberangkatan::query()
            ->with('jadwalToPenumpang')
            ->where('id_jadwal', $id_jadwal)->get();

        return response()->json($jadwal, 200);
    }

    public function view_tujuan($id_rute) {
        $jadwal = JadwalKeberangkatan::query()
            ->with('jadwalToPenumpang')
            ->where('id_rute', $id_rute)->get();

        return response()->json($jadwal, 200);
    }

    public function view_kapal($id_kapal) {
        $jadwal = JadwalKeberangkatan::query()
            ->with('jadwalToArmada')
            ->with('jadwalToKapal')
            ->with('jadwalToRute')
            ->with('jadwalToPenumpang')
            ->where('id_kapal', $id_kapal)->get();

        return response()->json($jadwal, 200);
    }
}
