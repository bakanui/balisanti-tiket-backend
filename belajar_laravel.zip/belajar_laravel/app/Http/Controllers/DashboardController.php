<?php

namespace App\Http\Controllers;

use App\Armada;
use App\JenisPenumpang;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    //
    public function grafikPenumpang($query) {
        $armadas = Armada::all();

        if($query == 3) {
            $data = array(
                'time' => Carbon::now('+08:00')->format('Y'),
                'labels' => ['1','2','3','4','5','6','7','8','9','10','11','12'],
                'datasets' => array()
            );
            foreach ($armadas as $armada) {
                $temp = [0,0,0,0,0,0,0,0,0,0,0,0];

                $jadwals = DB::table('keberangkatans as k')
                    ->select(DB::raw('month(tanggal_keberangkatan) as bulan'), DB::raw('COUNT(k.id_penumpang) as total'))
                    ->join('jadwal_keberangkatans as jk', 'jk.id_jadwal', '=', 'k.id_jadwal')
                    ->where('jk.id_armada','=', $armada['id_armada'])
                    ->whereYear('k.tanggal_keberangkatan', Carbon::now('+08:00'))
                    ->groupBy('bulan')
                    ->get();
                foreach ($jadwals as $jadwal) {
                    $temp[$jadwal->bulan-1] = $jadwal->total;
                }
                $data['datasets'][] = [
                    'nama_armada' => $armada['nama_armada'],
                    'data' => $temp
                ];
            }

            return response()->json($data, 200);
        }
        else if ($query == 2) {
            $data = array(
                'time' => Carbon::now('+08:00')->format('M Y'),
                'labels' => ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31'],
                'datasets' => array()
            );
            foreach ($armadas as $armada) {
                $temp = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
                $jadwals = DB::table('keberangkatans as k')
                    ->select(DB::raw('day(tanggal_keberangkatan) as tanggal'), DB::raw('COUNT(k.id_penumpang) as total'))
                    ->join('jadwal_keberangkatans as jk', 'jk.id_jadwal', '=', 'k.id_jadwal')
                    ->where('jk.id_armada','=', $armada['id_armada'])
                    ->whereYear('k.tanggal_keberangkatan', Carbon::now('+08:00'))
                    ->whereMonth('k.tanggal_keberangkatan', Carbon::now('+08:00'))
                    ->groupBy('tanggal')
                    ->get();
                foreach ($jadwals as $jadwal) {
                    $temp[$jadwal->tanggal-1] = $jadwal->total;
                }

                $data['datasets'][] = [
                    'nama_armada' => $armada['nama_armada'],
                    'data' => $temp
                ];
            }

            return response()->json($data, 200);
        }
        else {
            $data = array(
                'time' => Carbon::now('+08:00')->format('d, M Y'),
                'labels' => ['01:00','02:00','03:00','04:00','05:00','06:00','07:00','08:00','09:00','10:00','11:00','12:00','13:00','14:00','15:00','16:00','17:00','18:00','19:00','20:00','21:00','22:00','23:00','24:00'],
                'datasets' => array()
            );
            foreach ($armadas as $armada) {
                $temp = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
                $jadwals = DB::table('keberangkatans as k')
                    ->select(DB::raw('hour(tanggal_keberangkatan) as hari'), DB::raw('COUNT(k.id_penumpang) as total'))
                    ->join('jadwal_keberangkatans as jk', 'jk.id_jadwal', '=', 'k.id_jadwal')
                    ->where('jk.id_armada','=', $armada['id_armada'])
                    ->whereYear('k.tanggal_keberangkatan', Carbon::now('+08:00'))
                    ->whereMonth('k.tanggal_keberangkatan', Carbon::now('+08:00'))
                    ->whereDay('k.tanggal_keberangkatan', Carbon::now('+08:00'))
                    ->groupBy('hari')
                    ->get();
                foreach ($jadwals as $jadwal) {
                    $temp[$jadwal->hari-1] = $jadwal->total;
                }

                $data['datasets'][] = [
                    'nama_armada' => $armada['nama_armada'],
                    'data' => $temp
                ];
            }

            return response()->json($data, 200);
        }
    }

    public function grafikKeberangkatan($query) {
        if($query == 3) {
            $data = array(
                'time' => Carbon::now('+08:00')->format('Y'),
            );
            $temp = DB::table('keberangkatans as k')
            ->select(DB::raw('count(k.tanggal_keberangkatan) as total'), 'a.nama_armada')
            ->join('jadwal_keberangkatans as jk', 'jk.id_jadwal', '=', 'k.id_jadwal')
            ->join('armadas as a', 'jk.id_armada', '=', 'a.id_armada')
            ->whereYear('k.tanggal_keberangkatan', Carbon::now('+08:00'))
            ->groupBy('a.id_armada')
            ->get();

            foreach ($temp as $value) {
                $data['total'][] = $value->total;
                $data['labels'][] = $value->nama_armada;
            }

            return response()->json($data, 200);
        }
        else if($query == 2) {
            $data = array(
                'time' => Carbon::now('+08:00')->format('M Y'),
            );
            $temp = DB::table('keberangkatans as k')
            ->select(DB::raw('count(k.tanggal_keberangkatan) as total'), 'a.nama_armada')
            ->join('jadwal_keberangkatans as jk', 'jk.id_jadwal', '=', 'k.id_jadwal')
            ->join('armadas as a', 'jk.id_armada', '=', 'a.id_armada')
            ->whereYear('k.tanggal_keberangkatan', Carbon::now('+08:00'))
            ->whereMonth('k.tanggal_keberangkatan', Carbon::now('+08:00'))
            ->groupBy('a.id_armada')
            ->get();

            foreach ($temp as $value) {
                $data['total'][] = $value->total;
                $data['labels'][] = $value->nama_armada;
            }

            return response()->json($data, 200);
        }
        else {
            $data = array(
                'time' => Carbon::now('+08:00')->format('d, M Y'),
            );
            $temp = DB::table('keberangkatans as k')
            ->select(DB::raw('count(k.tanggal_keberangkatan) as total'), 'a.nama_armada')
            ->join('jadwal_keberangkatans as jk', 'jk.id_jadwal', '=', 'k.id_jadwal')
            ->join('armadas as a', 'jk.id_armada', '=', 'a.id_armada')
            ->whereYear('k.tanggal_keberangkatan', Carbon::now('+08:00'))
            ->whereMonth('k.tanggal_keberangkatan', Carbon::now('+08:00'))
            ->whereDay('k.tanggal_keberangkatan', Carbon::now('+08:00'))
            ->groupBy('a.id_armada')
            ->get();

            foreach ($temp as $value) {
                $data['total'][] = $value->total;
                $data['labels'][] = $value->nama_armada;
            }

            return response()->json($data, 200);
        }
    }

    public function grafikKapal() {
        $data = array(
            'time' => Carbon::now('+08:00')->format('d, M Y'),
        );
        $temp = DB::table('keberangkatans as k')
        ->select(DB::raw('count(jk.id_kapal) as total'), 'a.nama_armada')
        ->join('jadwal_keberangkatans as jk', 'jk.id_jadwal', '=', 'k.id_jadwal')
        ->join('armadas as a', 'jk.id_armada', '=', 'a.id_armada')
        ->join('history_keberangkatan as hk', 'jk.id_jadwal', '=', 'hk.id_jadwal')
        ->whereYear('k.tanggal_keberangkatan', Carbon::now('+08:00'))
        ->whereMonth('k.tanggal_keberangkatan', Carbon::now('+08:00'))
        ->whereDay('k.tanggal_keberangkatan', Carbon::now('+08:00'))
        ->groupBy('a.id_armada')
        ->get();

        foreach ($temp as $value) {
            $data['total'][] = $value->total;
            $data['labels'][] = $value->nama_armada;
        }

        return response()->json($data, 200);
    }

    public function grafikJenis($query) {
        $jenis = JenisPenumpang::all();

        if($query == 3) {
            $data = array(
                'time' => Carbon::now('+08:00')->format('Y'),
                'labels' => ['1','2','3','4','5','6','7','8','9','10','11','12'],
                'datasets' => array()
            );
            foreach ($jenis as $value) {
                $temp = [0,0,0,0,0,0,0,0,0,0,0,0];

                $jadwals = DB::table('keberangkatans as k')
                    ->select(DB::raw('month(tanggal_keberangkatan) as bulan'), DB::raw('COUNT(k.id_penumpang) as total'))
                    ->join('penumpangs as p', 'p.id', '=', 'k.id_penumpang')
                    ->where('p.id_jns_penum','=', $value['id_jns_penum'])
                    ->whereYear('k.tanggal_keberangkatan', Carbon::now('+08:00'))
                    ->groupBy('bulan')
                    ->get();

                foreach ($jadwals as $jadwal) {
                    $temp[$jadwal->bulan-1] = $jadwal->total;
                }

                $data['datasets'][] = [
                    'nama_armada' => $value['nama_jns_penum'],
                    'data' => $temp
                ];
            }

            return response()->json($data, 200);
        }
        else if ($query == 2) {
            $data = array(
                'time' => Carbon::now('+08:00')->format('M Y'),
                'labels' => ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31'],
                'datasets' => array()
            );
            foreach ($jenis as $value) {
                $temp = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];

                $jadwals = DB::table('keberangkatans as k')
                    ->select(DB::raw('day(tanggal_keberangkatan) as hari'), DB::raw('COUNT(k.id_penumpang) as total'))
                    ->join('penumpangs as p', 'p.id', '=', 'k.id_penumpang')
                    ->where('p.id_jns_penum','=', $value['id_jns_penum'])
                    ->whereYear('k.tanggal_keberangkatan', Carbon::now('+08:00'))
                    ->whereMonth('k.tanggal_keberangkatan', Carbon::now('+08:00'))
                    ->groupBy('hari')
                    ->get();

                foreach ($jadwals as $jadwal) {
                    $temp[$jadwal->hari-1] = $jadwal->total;
                }

                $data['datasets'][] = [
                    'nama_armada' => $value['nama_jns_penum'],
                    'data' => $temp
                ];
            }

            return response()->json($data, 200);
        }
        else {
            $data = array(
                'time' => Carbon::now('+08:00')->format('d, M Y'),
                'labels' => ['01:00','02:00','03:00','04:00','05:00','06:00','07:00','08:00','09:00','10:00','11:00','12:00','13:00','14:00','15:00','16:00','17:00','18:00','19:00','20:00','21:00','22:00','23:00','24:00'],
                'datasets' => array()
            );
            foreach ($jenis as $value) {
                $temp = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];

                $jadwals = DB::table('keberangkatans as k')
                    ->select(DB::raw('hour(tanggal_keberangkatan) as hari'), DB::raw('COUNT(k.id_penumpang) as total'))
                    ->join('penumpangs as p', 'p.id', '=', 'k.id_penumpang')
                    ->where('p.id_jns_penum','=', $value['id_jns_penum'])
                    ->whereYear('k.tanggal_keberangkatan', Carbon::now('+08:00'))
                    ->whereMonth('k.tanggal_keberangkatan', Carbon::now('+08:00'))
                    ->whereDay('k.tanggal_keberangkatan', Carbon::now('+08:00'))
                    ->groupBy('hari')
                    ->get();

                foreach ($jadwals as $jadwal) {
                    $temp[$jadwal->hari-1] = $jadwal->total;
                }

                $data['datasets'][] = [
                    'nama_armada' => $value['nama_jns_penum'],
                    'data' => $temp
                ];
            }

            return response()->json($data, 200);
        }
    }

}
