<?php

namespace App\Http\Controllers;

use App\JadwalKeberangkatan;
use App\Penumpang;
use Illuminate\Http\Request;

class PenumpangController extends Controller
{
    //
    public function store(Request $request) {
        $this->validate($request,[
            'nama_penumpang' => 'required|string',
            'no_identitas' => 'required|string',
            'id_jns_penum' => 'required',
            'id_tujuan' => 'required',
            'id_jadwal' => 'required'
        ]);

        $penumpang = new Penumpang([
            'nama_penumpang' => $request->input('nama_penumpang'),
            'no_identitas' => $request->input('no_identitas'),
            'id_jns_penum' => $request->input('id_jns_penum'),
            'id_tujuan' => $request->input('id_tujuan'),
            'id_jadwal' => '',
        ]);

        if ($penumpang->save()) {
            $response = [
                'message' => 'Penumpang created',
                'penumpang' => $penumpang
            ];

            $jadwal = JadwalKeberangkatan::query()->where('id_jadwal', $request->input('id_jadwal'))->firstOrFail();

            $jadwal->jadwalToPenumpang()->attach($penumpang);

            return response()->json($response, 201);
        }

        return response()->json(['message' => 'Penumpang not created'], 404);
    }

    public function view($id_penumpang) {
        $penumpang = Penumpang::query()
            ->with('penumpangToTujuan')
            ->with('penumpangToJenis')
            ->with('penumpangToJadwal')
            ->where('id', $id_penumpang)->first();

        $jadwal = $penumpang['penumpangToJadwal'];

        $return_jadwal = array();
//        foreach ($jadwal as $item) {
//            $jdwl = JadwalKeberangkatan::query()->with('')
//        }

        return response()->json($penumpang, 200);
    }

    public function index() {
        $penumpang = Penumpang::query()->with('penumpangToTujuan')->with('penumpangToJenis')->get();

        return response()->json($penumpang, 200);
    }

    public function edit(Request $request, $id_penumpang) {
        $this->validate($request,[
            'nama_penumpang' => 'required|string',
            'no_identitas' => 'required|string',
            'id_jns_penum' => 'required',
            'id_tujuan' => 'required',
            'id_jadwal' => 'required',
        ]);

        $penumpang = [
            'nama_penumpang' => $request->input('nama_penumpang'),
            'no_identitas' => $request->input('no_identitas'),
            'id_jns_penum' => $request->input('id_jns_penum'),
            'id_tujuan' => $request->input('id_tujuan'),
            'id_jadwal' => $request->input('id_jadwal'),
        ];

        $data = Penumpang::query()->with('penumpangToTujuan')->with('penumpangToJenis');

        if ($data) {
            if ($data->update($penumpang)) {
                $response = [
                    'message' => 'Penumpang created',
                    'penumpang' => $data->get()
                ];

                return response()->json($response, 201);
            }

            return response()->json(['message' => 'Penumpang not created'], 404);
        }

        return response()->json(['message' => 'Penumpang not found'], 404);
    }
}
