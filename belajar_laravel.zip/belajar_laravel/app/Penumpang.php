<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Penumpang extends Model
{
    use SoftDeletes;

    protected $dates = ['deleted_at'];
    //
    protected $fillable = [
        'nama_penumpang', 'no_identitas', 'id_jns_penum', 'id_tujuan', 'id_jadwal'
    ];

    public function penumpangToTujuan()
    {
        return $this->belongsTo('App\JenisTujuan', 'id_tujuan', 'id_tujuan');
    }

    public function penumpangToJenis()
    {
        return $this->belongsTo('App\JenisPenumpang', 'id_jns_penum', 'id_jns_penum');
    }

    public function penumpangToJadwal()
    {
        return $this->belongsToMany(
            JadwalKeberangkatan::class,
            'keberangkatans',
            'id_penumpang',
            'id_jadwal',
            'id',
            'id_jadwal'
        )
            ->select('jadwal_keberangkatans.*', 'keberangkatans.tanggal_keberangkatan')
            ->with('jadwalToRute')
            ->with('jadwalToNahkoda')
            ->with('jadwalToKapal');
    }
}
