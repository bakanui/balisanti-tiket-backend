<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Armada extends Model
{
    use SoftDeletes;

    protected $dates = ['deleted_at'];
    //
    protected $fillable = [
        'id_armada', 'id_user', 'nama_armada', 'kontak', 'alamat', 'description'
    ];

    public function armadaToUser()
    {
        return $this->hasMany('App\User', 'id', 'id_user');
    }
}
